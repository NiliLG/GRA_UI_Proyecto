﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FormsGraficos
{
    public partial class FrmLanzamientoH : Form
    {
        Graphics graphics;
        int posY = 50;
        int posX = 50;
        int ancho = 50;
        int alto = 50;
        public FrmLanzamientoH()
        {
            InitializeComponent();
            this.KeyPreview = true;
        }

        private void FrmLanzamientoH_Load(object sender, EventArgs e)
        {

        }
        
        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {
            graphics = e.Graphics;
            Pen pen = new Pen(Color.Blue, 3);
            Rectangle circleBounds = new Rectangle(posX, posY, ancho, alto); 
            graphics.DrawEllipse(pen, circleBounds);
        }

        private void FrmLanzamientoH_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Right)
            {
                posY += 10;
                posX += 10;
                if (posY == 200) { alto = 30; posY = 300; }
                pictureBox1.Refresh();
            }
        }
    }
}
